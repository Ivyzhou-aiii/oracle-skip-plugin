// Oracle Video Skipper - Content Script
// 自动运行，无需点击插件图标

(function () {
  'use strict';

  // 默认设置
  let settings = {
    enabled: true,
    speed: 16,
    autoSkip: true,
    autoNext: true
  };

  let isRunning = false;
  let skipInterval = null;

  // 立即启动
  console.log('[Oracle Skipper] 脚本已加载，准备启动...');
  
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }

  function init() {
    console.log('[Oracle Skipper] 初始化中...');
    
    // 读取设置
    chrome.storage.sync.get(['enabled', 'speed', 'autoSkip', 'autoNext'], (data) => {
      if (data.enabled !== undefined) settings.enabled = data.enabled;
      if (data.speed !== undefined) settings.speed = parseFloat(data.speed) || 16;
      if (data.autoSkip !== undefined) settings.autoSkip = data.autoSkip;
      if (data.autoNext !== undefined) settings.autoNext = data.autoNext;
      
      if (settings.enabled) {
        startAutoSkip();
      }
    });
  }

  function startAutoSkip() {
    if (isRunning) return;
    isRunning = true;
    
    console.log('[Oracle Skipper] 自动跳过模式已启动');
    
    // 立即执行一次
    forceSkipAll();
    
    // 每2秒检查一次
    skipInterval = setInterval(() => {
      forceSkipAll();
    }, 2000);
    
    // 监听页面变化
    observePageChanges();
  }

  // ─── 核心：强制跳过所有视频 ────────────────────────────────────────────
  function forceSkipAll() {
    // 1. 处理所有 video 元素
    document.querySelectorAll('video').forEach(processVideo);
    
    // 2. 处理 iframe 内的视频
    processIframes();
    
    // 3. 解锁所有按钮
    unlockButtons();
    
    // 4. 触发完成事件
    triggerCompletion();
    
    // 5. 修改进度数据
    hackProgressData();
  }

  function processVideo(video) {
    if (!video || video._oracleSkipperDone) return;
    
    try {
      // 标记已处理
      video._oracleSkipperDone = true;
      
      console.log('[Oracle Skipper] 处理视频:', video.src || 'unknown');
      
      // 设置倍速
      video.playbackRate = settings.speed;
      
      // 静音（避免噪音）
      video.muted = true;
      
      // 尝试播放
      video.play().catch(() => {});
      
      // 获取真实时长并跳到末尾
      const trySkip = () => {
        const duration = video.duration || 
                        (video.seekable && video.seekable.length > 0 ? video.seekable.end(0) : 0);
        
        if (duration && duration > 0 && isFinite(duration)) {
          console.log('[Oracle Skipper] 跳到末尾:', duration);
          video.currentTime = duration - 0.5;
          
          // 触发结束事件
          setTimeout(() => {
            video.dispatchEvent(new Event('ended', { bubbles: true }));
            video.dispatchEvent(new Event('pause', { bubbles: true }));
          }, 100);
        }
      };
      
      // 如果已加载元数据，立即跳过
      if (video.readyState >= 1) {
        trySkip();
      } else {
        // 否则等待加载
        video.addEventListener('loadedmetadata', trySkip, { once: true });
        // 备用：2秒后强制跳过
        setTimeout(trySkip, 2000);
      }
      
      // 持续保持倍速和跳过状态
      const keepSkipping = setInterval(() => {
        if (video.playbackRate < settings.speed) {
          video.playbackRate = settings.speed;
        }
        
        const duration = video.duration;
        if (duration && video.currentTime < duration - 1) {
          video.currentTime = duration - 0.5;
        }
        
        // 如果视频已结束或被移除，停止定时器
        if (video.ended || !document.contains(video)) {
          clearInterval(keepSkipping);
        }
      }, 1000);
      
    } catch (e) {
      console.log('[Oracle Skipper] 处理视频失败:', e);
    }
  }

  // ─── 处理 iframe ───────────────────────────────────────────────────────
  function processIframes() {
    document.querySelectorAll('iframe').forEach(iframe => {
      try {
        // 尝试访问同域 iframe
        const iframeDoc = iframe.contentDocument || iframe.contentWindow?.document;
        if (iframeDoc) {
          iframeDoc.querySelectorAll('video').forEach(processVideo);
        }
      } catch (e) {
        // 跨域 iframe，尝试 postMessage
        try {
          iframe.contentWindow?.postMessage({
            type: 'ORACLE_SKIPPER_SKIP',
            speed: settings.speed
          }, '*');
        } catch (e2) {}
      }
    });
  }

  // ─── 解锁按钮 ──────────────────────────────────────────────────────────
  function unlockButtons() {
    const keywords = ['next', '下一', 'continue', '继续', 'proceed', 'advance',
                     'complete', '完成', 'mark complete', 'launch', 'start'];
    
    document.querySelectorAll('button, a, [role="button"], input').forEach(btn => {
      const text = (btn.textContent || btn.value || btn.getAttribute('aria-label') || '').toLowerCase();
      
      if (keywords.some(k => text.includes(k))) {
        // 移除所有禁用属性
        btn.removeAttribute('disabled');
        btn.removeAttribute('aria-disabled');
        btn.disabled = false;
        
        // 移除禁用类
        btn.classList.remove('disabled', 'oj-disabled', 'locked', 'btn-disabled');
        
        // 确保可点击
        btn.style.pointerEvents = 'auto';
        btn.style.opacity = '1';
        btn.style.cursor = 'pointer';
        
        // 自动点击"下一步"按钮
        if (settings.autoNext && 
            (text.includes('next') || text.includes('下一') || 
             text.includes('continue') || text.includes('继续'))) {
          // 检查是否已解锁
          if (!btn.disabled && btn.offsetParent !== null) {
            console.log('[Oracle Skipper] 自动点击:', text.slice(0, 30));
            btn.click();
          }
        }
      }
    });
  }

  // ─── 触发完成事件 ──────────────────────────────────────────────────────
  function triggerCompletion() {
    // SCORM 1.2
    try {
      if (window.API && window.API.LMSSetValue) {
        window.API.LMSSetValue('cmi.core.lesson_status', 'completed');
        window.API.LMSSetValue('cmi.core.score.raw', '100');
        window.API.LMSCommit('');
      }
    } catch (e) {}
    
    // SCORM 2004
    try {
      if (window.API_1484_11 && window.API_1484_11.SetValue) {
        window.API_1484_11.SetValue('cmi.completion_status', 'completed');
        window.API_1484_11.SetValue('cmi.success_status', 'passed');
        window.API_1484_11.SetValue('cmi.score.raw', '100');
        window.API_1484_11.Commit('');
      }
    } catch (e) {}
    
    // 触发视频结束事件
    document.querySelectorAll('video').forEach(video => {
      try {
        video.dispatchEvent(new Event('ended', { bubbles: true }));
      } catch (e) {}
    });
  }

  // ─── 修改进度数据 ──────────────────────────────────────────────────────
  function hackProgressData() {
    // 修改全局变量
    const vars = ['videoProgress', 'lessonProgress', 'courseProgress', 'completionPercent'];
    vars.forEach(v => {
      if (window[v] !== undefined) {
        try {
          window[v] = 100;
        } catch (e) {}
      }
    });
    
    // 修改 localStorage
    try {
      Object.keys(localStorage).forEach(key => {
        if (key.toLowerCase().includes('progress') || 
            key.toLowerCase().includes('video') ||
            key.toLowerCase().includes('lesson') ||
            key.toLowerCase().includes('course')) {
          try {
            const data = JSON.parse(localStorage.getItem(key));
            if (typeof data === 'object') {
              if (data.progress !== undefined) data.progress = 100;
              if (data.completed !== undefined) data.completed = true;
              if (data.percent !== undefined) data.percent = 100;
              if (data.watched !== undefined) data.watched = data.duration || 99999;
              localStorage.setItem(key, JSON.stringify(data));
            }
          } catch (e) {}
        }
      });
    } catch (e) {}
  }

  // ─── 监听页面变化 ──────────────────────────────────────────────────────
  function observePageChanges() {
    const observer = new MutationObserver(() => {
      // 有新元素加入时重新处理
      setTimeout(forceSkipAll, 500);
    });
    
    observer.observe(document.body, { 
      childList: true, 
      subtree: true,
      attributes: true,
      attributeFilter: ['disabled', 'class']
    });
  }

  // ─── 监听来自 popup 的消息 ─────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'forceSkip') {
      forceSkipAll();
      sendResponse({ 
        success: true, 
        videoCount: document.querySelectorAll('video').length 
      });
    }
    
    if (message.action === 'getStatus') {
      sendResponse({
        videoCount: document.querySelectorAll('video').length,
        isRunning: isRunning,
        settings: settings
      });
    }
    
    if (message.action === 'updateSettings') {
      settings = { ...settings, ...message.settings };
      sendResponse({ success: true });
    }
  });

  // ─── 监听 postMessage（来自 iframe）────────────────────────────────────
  window.addEventListener('message', (e) => {
    if (e.data && e.data.type === 'ORACLE_SKIPPER_SKIP') {
      forceSkipAll();
    }
  });

})();
