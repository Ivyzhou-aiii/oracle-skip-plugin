import struct
import zlib
import os

def make_png(size, r, g, b):
    """Generate a simple solid-color PNG"""
    def chunk(name, data):
        c = zlib.crc32(name + data) & 0xffffffff
        return struct.pack('>I', len(data)) + name + data + struct.pack('>I', c)

    ihdr = struct.pack('>IIBBBBB', size, size, 8, 2, 0, 0, 0)
    raw = b''.join(b'\x00' + bytes([r, g, b] * size) for _ in range(size))
    idat = zlib.compress(raw)

    return (b'\x89PNG\r\n\x1a\n' +
            chunk(b'IHDR', ihdr) +
            chunk(b'IDAT', idat) +
            chunk(b'IEND', b''))

icons_dir = r'C:\Users\i.zhou\WorkBuddy\20260416104558\oracle-skip-plugin\icons'
os.makedirs(icons_dir, exist_ok=True)

for size in [16, 48, 128]:
    png_data = make_png(size, 199, 74, 0)
    with open(os.path.join(icons_dir, f'icon{size}.png'), 'wb') as f:
        f.write(png_data)

print('Icons generated OK')
