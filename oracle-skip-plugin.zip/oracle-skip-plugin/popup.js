// Popup 脚本 - 只显示状态，不控制视频

document.addEventListener('DOMContentLoaded', () => {
  const statusEl = document.getElementById('status');
  const videoCountEl = document.getElementById('videoCount');
  const toggleBtn = document.getElementById('toggle');
  const refreshBtn = document.getElementById('refresh');
  const speedSelect = document.getElementById('speed');
  const autoSkipCheck = document.getElementById('autoSkip');
  const autoNextCheck = document.getElementById('autoNext');

  let settings = {
    enabled: true,
    speed: 16,
    autoSkip: true,
    autoNext: true
  };

  // 加载设置
  chrome.storage.sync.get(['enabled', 'speed', 'autoSkip', 'autoNext'], (data) => {
    settings = { ...settings, ...data };
    updateUI();
  });

  function updateUI() {
    toggleBtn.textContent = settings.enabled ? '暂停插件' : '启用插件';
    toggleBtn.className = settings.enabled ? 'btn btn-danger' : 'btn btn-primary';
    speedSelect.value = settings.speed;
    autoSkipCheck.checked = settings.autoSkip;
    autoNextCheck.checked = settings.autoNext;
    
    statusEl.textContent = settings.enabled ? '✅ 自动跳过已启用' : '⏸️ 已暂停';
  }

  // 获取当前标签页状态
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]) {
      chrome.tabs.sendMessage(tabs[0].id, { action: 'getStatus' }, (response) => {
        if (response) {
          videoCountEl.textContent = `检测到 ${response.videoCount} 个视频`;
        } else {
          videoCountEl.textContent = '未检测到视频页面';
        }
      });
    }
  });

  // 切换启用/暂停
  toggleBtn.addEventListener('click', () => {
    settings.enabled = !settings.enabled;
    chrome.storage.sync.set({ enabled: settings.enabled }, () => {
      updateUI();
      // 通知 content script
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, { 
            action: 'updateSettings', 
            settings: settings 
          });
        }
      });
    });
  });

  // 刷新状态
  refreshBtn.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { action: 'getStatus' }, (response) => {
          if (response) {
            videoCountEl.textContent = `检测到 ${response.videoCount} 个视频`;
          }
        });
      }
    });
  });

  // 修改倍速
  speedSelect.addEventListener('change', (e) => {
    settings.speed = parseFloat(e.target.value);
    chrome.storage.sync.set({ speed: settings.speed });
    // 通知 content script
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, { 
          action: 'updateSettings', 
          settings: settings 
        });
      }
    });
  });

  // 修改自动跳过
  autoSkipCheck.addEventListener('change', (e) => {
    settings.autoSkip = e.target.checked;
    chrome.storage.sync.set({ autoSkip: settings.autoSkip });
  });

  // 修改自动下一步
  autoNextCheck.addEventListener('change', (e) => {
    settings.autoNext = e.target.checked;
    chrome.storage.sync.set({ autoNext: settings.autoNext });
  });
});
